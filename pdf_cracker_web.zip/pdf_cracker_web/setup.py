import os
import subprocess
import sys
import platform

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
WORDLIST_PATH = os.path.join(PROJECT_DIR, "wordlists", "rockyou.txt")
VENV_PATH = os.path.join(PROJECT_DIR, "venv")
PYTHON_BIN = os.path.join(VENV_PATH, "bin", "python")
PIP_BIN = os.path.join(VENV_PATH, "bin", "pip")

def detect_os():
    system = platform.system()
    if system == "Darwin":
        return "mac"
    elif system == "Windows":
        return "windows"
    elif system == "Linux":
        return "linux"
    else:
        return "unknown"

def ensure_virtualenv():
    if not os.path.exists(VENV_PATH):
        print("[+] Creating virtual environment...")
        subprocess.run(["python3", "-m", "venv", VENV_PATH])
    else:
        print("[✓] Virtual environment already exists.")

def ensure_wordlist():
    if not os.path.exists(WORDLIST_PATH):
        print("[+] Downloading rockyou.txt...")
        os.makedirs(os.path.dirname(WORDLIST_PATH), exist_ok=True)
        subprocess.run([
            "wget",
            "https://github.com/brannondorsey/naive-hashcat/releases/download/data/rockyou.txt",
            "-O", WORDLIST_PATH
        ])
    else:
        print("[✓] rockyou.txt already exists.")

def ensure_john(os_type):
    result = subprocess.run(["where" if os_type == "windows" else "which", "john"], capture_output=True, text=True)
    if not result.stdout.strip():
        print("[+] Installing John the Ripper...")
        if os_type == "linux":
            subprocess.run(["sudo", "apt", "install", "-y", "john"])
        elif os_type == "mac":
            subprocess.run(["brew", "install", "john"])
        else:
            print("[!] Please install John manually.")
    else:
        print("[✓] John the Ripper is installed.")

def ensure_python_packages():
    print("[+] Installing Python packages in virtual environment...")
    subprocess.run([PIP_BIN, "install", "--upgrade", "pip"])
    subprocess.run([PIP_BIN, "install", "flask", "pyhanko==0.20.1"])

def check_pyhanko():
    result = subprocess.run([PYTHON_BIN, "-c", "import pyhanko"], capture_output=True)
    if result.returncode != 0:
        print("[!] pyhanko is still missing. Check virtual environment usage.")
    else:
        print("[✓] pyhanko is available.")

def run_app():
    print("[+] Launching app with virtual environment Python...")
    try:
        subprocess.run([PYTHON_BIN, "app.py"])
    except KeyboardInterrupt:
        print("\n[✓] Server stopped by user.")


def setup_environment():
    os_type = detect_os()
    print(f"[✓] Detected OS: {os_type}")
    ensure_virtualenv()
    ensure_wordlist()
    ensure_john(os_type)
    ensure_python_packages()
    check_pyhanko()
    run_app()

if __name__ == "__main__":
    setup_environment()


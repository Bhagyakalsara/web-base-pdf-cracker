import subprocess
import os

def extract_hash(pdf_path, hash_file):
    if not os.path.exists("pdf2john.py"):
        subprocess.run([
            "wget",
            "https://raw.githubusercontent.com/openwall/john/bleeding-jumbo/run/pdf2john.py",
            "-O", "pdf2john.py"
        ])
        subprocess.run(["chmod", "+x", "pdf2john.py"])

    subprocess.run(f"python3 pdf2john.py '{pdf_path}' > {hash_file}", shell=True)

    if not os.path.exists(hash_file) or os.path.getsize(hash_file) == 0:
        return None

    with open(hash_file, "r") as f:
        return f.read().strip()

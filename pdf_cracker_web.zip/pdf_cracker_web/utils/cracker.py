import subprocess

def crack_pdf(hash_path, wordlist_path):
    try:
        result = subprocess.run(
            ["john", "--wordlist=" + wordlist_path, hash_path],
            capture_output=True, text=True
        )
        show = subprocess.run(
            ["john", "--show", "--format=PDF", hash_path],
            capture_output=True, text=True
        )
        return result.stdout + "\n" + show.stdout
    except Exception as e:
        return f"Cracking failed: {str(e)}"

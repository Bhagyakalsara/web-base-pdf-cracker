import os
import sqlite3
from flask import Flask, request, render_template
from werkzeug.utils import secure_filename
from pdf2john import PdfHashExtractor
from utils.cracker import crack_pdf


app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def log_result(filename, hash, password):
    conn = sqlite3.connect("log.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT,
            hash TEXT,
            cracked_password TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("INSERT INTO logs (filename, hash, cracked_password) VALUES (?, ?, ?)",
                   (filename, hash, password))
    conn.commit()
    conn.close()

@app.route("/", methods=["GET", "POST"])
def index():
    hash_output = ""
    crack_output = ""
    encryption_info = ""
    error_msg = ""

    if request.method == "POST":
        pdf_file = request.files["pdf_file"]
        wordlist_file = request.files.get("wordlist_file")

        filename = secure_filename(pdf_file.filename)
        pdf_path = os.path.join(UPLOAD_FOLDER, filename)
        pdf_file.save(pdf_path)

        wordlist_path = "wordlists/rockyou.txt"
        if wordlist_file:
            wordlist_name = secure_filename(wordlist_file.filename)
            wordlist_path = os.path.join(UPLOAD_FOLDER, wordlist_name)
            wordlist_file.save(wordlist_path)

        try:
            extractor = PdfHashExtractor(pdf_path)
            hash_output = extractor.parse()
            encryption_info = f"Encryption Type: {'AES' if extractor.algorithm == 5 else 'RC4'}, Revision: {extractor.revision}"

            with open("hash.txt", "w") as f:
                f.write(hash_output)

            crack_output = crack_pdf("hash.txt", wordlist_path)

            log_result(filename, hash_output, crack_output.strip())

            if "No such file or directory" in crack_output:
                error_msg = "Wordlist not found. Please upload a valid wordlist."
            elif "0 password hashes cracked" in crack_output:
                error_msg = "No password cracked. Try a larger wordlist or check encryption type."

        except Exception as e:
            error_msg = f"Error: {str(e)}"

    return render_template("index.html",
                           hash_output=hash_output,
                           crack_output=crack_output,
                           encryption_info=encryption_info,
                           error_msg=error_msg)

if __name__ == "__main__":
    app.run(debug=True)
